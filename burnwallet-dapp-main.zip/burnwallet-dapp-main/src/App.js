/**
 * App
 * Author: Nauman Sukhera
 * Date: 6 Oct, 2023
 */
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import React from 'react';
import Home from './pages/home';
const App = () => {
  return (
    <div className="wrapper">
      <Home />
    </div>
  );
};

export default App;
