/**
 * Charges burn Fee from user and sends an email.
 * Author: Nauman Sukhera
 * Date: 6 Oct, 2023
 * Update 1 (13 Oct, 2023): Added validation for fee transaction.
 * Removed EmailJS
 * Added custom email service
 * MailGun config in sendemail.php
 * Update 2 (19 Oct, 2023): Added Please wait bar for transaction processing
 * Update 3 (15 Nov, 2023): integrated send email and  refund handle function
 *                          Removed php file

 *
 */

import Moralis from 'moralis';
import { ethers } from 'ethers';
import Swal from 'sweetalert2';
import axios from 'axios';
import { useState, useEffect } from 'react';
import {
  usePrepareSendTransaction,
  useSendTransaction,
  useWaitForTransaction,
  useNetwork,
  useTransaction,
  useFeeData,
  useAccount
} from 'wagmi';
import Web3 from 'web3';
import { Button, Image } from 'react-bootstrap';

import { FEE_ADDRESS, IS_MAINNET, API_URL } from '../../config';
import { TOKEN_ADDRESS_MAINNET } from '../../utils/token_chains';
import { RPC } from '../../utils/rpc_chain';
import { MAINNET_CHAIN_ID } from '../../utils/mainnetChains';
import { BurnTransactionTable } from '../burnTransactionTable';
import exclamationIcon from '../../assets/images/exclamation-icon.svg';
import { SendEmail } from '../../utils/sendMail';
import { registerTransaction } from '../../utils/registerTransaction';
import { EmailFrom } from '../emailForm';

const BurnTransactionFee = ({
  setNativePrice,
  nativePrice,
  selectedTokens,
  setExecute,
  fee,
  setFee,
  execute,
  setCallPrice,
  callPrice,
  handleClose,
  setShowCongrats,
  dollarFee,
  setDollarFee,
  setShowTrnxScreen,
  setBurnFeeGas
}) => {
  const { chain } = useNetwork();
  const { address } = useAccount();
  const web3 = new Web3(RPC[chain.id]);
  const { data: feeData } = useFeeData({ staleTime: 1_000, chainId: chain.id });

  const [localNativePrice, setLocalNativePrice] = useState(10);
  const [primaryFee, setPrimaryFee] = useState(0);
  const [secondaryFee, setsetSecondaryFee] = useState(0);
  const [burnTokens, setBurnTokens] = useState([]);
  const [email, setEmail] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [displayStatus, setDisplayStatus] = useState();
  const [isSuccess, setIsSuccess] = useState(false);

  const calculateFee = () => {
    const tokensCount = selectedTokens.length;
    setFee(((primaryFee + secondaryFee * (tokensCount - 1)) / localNativePrice).toFixed(6));
  };

  const getNativePrice = async () => {
    axios
      .get(`${API_URL}/fee/get`)
      .then(async (res) => {
        setPrimaryFee(parseFloat(res.data.data.fee.primaryFee));
        setsetSecondaryFee(parseFloat(res.data.data.fee.secondaryFee));
        const options = {
          address: TOKEN_ADDRESS_MAINNET[chain.id],
          chain: IS_MAINNET ? chain.id : MAINNET_CHAIN_ID[chain.id] // Always fetch price from mainnnet
        };
        const price = await Moralis.EvmApi.token.getTokenPrice(options);
        setNativePrice(price.jsonResponse.usdPrice.toFixed(6));
        setLocalNativePrice(price.jsonResponse.usdPrice.toFixed(6));
      })
      .catch((err) => {
        // Incase fee or Moralis Api is down
        handleClose();
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Website is down! Please try again '
        });
      });
  };

  //Burn Fee Trnx
  const { config } = usePrepareSendTransaction({
    to: FEE_ADDRESS,
    value: ethers.parseEther(fee?.toString())
  });

  const { data, sendTransaction } = useSendTransaction(config);

  useEffect(() => {
    calculateFee();
  }, [execute, selectedTokens.length]); // eslint-disable-line react-hooks/exhaustive-deps

  const { isLoading, status, isError, error } = useWaitForTransaction({
    hash: data?.hash
  });

  const { data: useTransactionData } = useTransaction({
    hash: data?.hash
  });

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const proceedNext = async () => {
    if (selectedTokens.length === burnTokens.length) {
      if (email) {
        SendEmail(email, burnTokens, primaryFee, secondaryFee, localNativePrice, chain, fee);
      }
      setShowCongrats(true);
      setExecute(false);
      setShowTrnxScreen(false);
    } else {
      Swal.fire({
        icon: 'warning',
        title: 'Oops...',
        html: 'Please burn all your tokens.<br> We deducted the burn fee, please burn all pending tokens.',
        confirmButtonColor: '#5C8E00'
      });
    }
  };

  useEffect(() => {
    if (address && selectedTokens.length > 0 && feeData != null) {
      const getGasAmount = async () => {
        try {
          const gasAmount = await web3.eth.estimateGas({
            to: FEE_ADDRESS,
            from: address,
            value: ethers.parseEther(fee?.toString())
          });

          setBurnFeeGas(web3.utils.fromWei(BigInt(gasAmount) * BigInt(feeData?.gasPrice), 'ether'));

          return gasAmount;
        } catch (error) {
          return 0;
        }
      };
      getGasAmount();
    }
  }, [dollarFee]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (callPrice) {
      setCallPrice(false);
      getNativePrice();
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (isError === true) {
      Swal.fire({
        icon: 'error',
        title: 'Erorr in processing transaction!',
        text: ''
      });
      setDisplayStatus('Erorr in processing');
    }
  }, [isError, error]);

  useEffect(() => {
    if (status === 'idle') {
      setDisplayStatus('Pending');
    } else if (status === 'loading') {
      setIsProcessing(true);
      setDisplayStatus('Processing');
    } else if (status === 'success') {
      //  Validiation after transaction
      if (
        useTransactionData.to.toLocaleUpperCase() === FEE_ADDRESS.toLocaleUpperCase() &&
        useTransactionData.value === ethers.parseEther(fee?.toString())
      ) {
        const addresses = selectedTokens.map((token) => ({
          tokenName: token.name,
          tokenAddress: token.address,
          tokenAmount: token.balance
        }));
        registerTransaction(data, addresses, chain, fee, address, dollarFee, localNativePrice);
        setIsSuccess(true);
        setIsProcessing(false);
        setDisplayStatus('Success');
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Transaction has been compromised !',
          html: "Please don't edit the transaction <br> Please pay again for the next transaction"
        });
        setIsProcessing(false);
        setDisplayStatus('Transaction Compromised');
      }
    }
  }, [status, useTransactionData]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (selectedTokens.length > 0) {
      setDollarFee(primaryFee + secondaryFee * (selectedTokens.length - 1));
    } else {
      setDollarFee(0);
    }
  }, [primaryFee, secondaryFee, selectedTokens]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      {execute && (
        <div className="wallet-modal-content-wrapper">
          <BurnTransactionTable
            isSuccess={isSuccess}
            selectedTokens={selectedTokens}
            setIsProcessing={setIsProcessing}
            setBurnTokens={setBurnTokens}
            burnTokens={burnTokens}
            data={data}
            fee={fee}
            chain={chain}
            displayStatus={displayStatus}
            isProcessing={isProcessing}
            sendTransaction={sendTransaction}
            handleClose={handleClose}
            isLoading={isLoading}
          ></BurnTransactionTable>
          {isProcessing ? (
            <div className="d-flex align-items-center p-2 bg-white border-radius-4 mt-4 mb-4">
              <div className="exclamation-icon me-3">
                <Image src={exclamationIcon} className="img-fluid" alt="exclamation icon" />
              </div>
              <p className="mb-0 email-transaction-info blinking-text text-danger">
                Please wait for the transaction to complete; it might take up to 2 minutes.
              </p>
            </div>
          ) : (
            ''
          )}
          <EmailFrom handleEmailChange={handleEmailChange} />

          {isSuccess === true ? (
            <Button
              className="btn-green"
              disabled={!isSuccess}
              onClick={() => {
                proceedNext();
              }}
            >
              Proceed
            </Button>
          ) : (
            // User only allowed to cancel transaction if burn fee is not paid
            <Button
              className="btn-red mb-4"
              disabled={isSuccess || isLoading}
              onClick={() => {
                handleClose(true);
              }}
            >
              Cancel
            </Button>
          )}
          <div className="d-flex align-items-center p-2 bg-white border-radius-4 mt-4">
            <div className="exclamation-icon me-3">
              <Image src={exclamationIcon} className="img-fluid" alt="exclamation icon" />
            </div>
            <p className="mb-0 email-transaction-info text-danger">
              Email is completely optional, we don’t store user's data and your privacy is respected
            </p>
          </div>
        </div>
      )}
    </>
  );
};
export default BurnTransactionFee;
