import { Button, Col, Container, Row, Image } from 'react-bootstrap';
import solutionImg from '../../assets/images/solution-col-img.png';
import './solution.css';
const Solution = ({ setShowModal }) => {
  const handleShow = () => {
    setShowModal(true);
  };

  return (
    <section className="solution">
      <Container>
        <Row>
          <Col lg="6">
            <div className="solution-img">
              <Image src={solutionImg} className="img-fluid" alt="solution img" />
            </div>
          </Col>
          <Col lg="6">
            <div className="solution-content">
              <h2 className="text-green">Solution</h2>
              <p>
                For your safety, for your security, for your peace of mind send these coins/tokens
                to BurnWallet.net. BurnWallet.net provides you a place to:
              </p>
              <ul>
                <li>Throw away unwanted/useless Tokens</li>
                <li>Send broken coins/tokens and help prevent potential tax issues</li>
                <li>Send malicious coins and tokens</li>
                <li>Help ensure accurate balance & wallet streamlining</li>
              </ul>
              <Button className="btn-green" onClick={handleShow}>
                Try Now
              </Button>
            </div>
          </Col>
        </Row>{' '}
      </Container>
    </section>
  );
};

export default Solution;
