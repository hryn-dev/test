/**
 * Handle refund and call api to backend .
 * Author: Nauman Sukhera
 * Date: 15 Nov, 2023
 */
import axios from 'axios';
import Swal from 'sweetalert2';

import { API_URL } from '../config';
export const handleRefund = (handleClose, data, selectedTokens, burnTokens) => {
  if (selectedTokens.length === burnTokens.length) {
    Swal.fire({
      icon: 'warning',
      title: 'Oops...',
      html: 'All tokens have been successfully burned.<br/> At this stage, refund claims are not accepted.',
      confirmButtonColor: '#5C8E00'
    });
  } else {
    Swal.fire({
      title: 'Are you sure to request refund ?',
      text: 'Please note that if your refund request is accepted, it will be reflected in your wallet within 10 days. Proceeding will close the current session, and this action is irreversible',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#5C8E00',
      cancelButtonColor: '#80808091',
      confirmButtonText: 'Proceed',
      cancelButtonText: 'Cancel'
    }).then((result) => {
      if (result.isConfirmed) {
        axios
          .post(`${API_URL}/refund/request`, { feeTransactionHash: data?.hash })
          .then((res) => {
            Swal.fire({
              icon: 'success',
              title: 'Refund requested!',
              text: 'if your refund request is accepted, it will be reflected in your wallet within 10 days.'
            });
            handleClose();
          })
          .catch((err) => {
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: err.message
            });
          });
      }
    });
  }
};
