/**
 * Display tokens ,display only valid Erc-20 tokens and allow user to select .
 * Author: Nauman Sukhera
 * Date: 6 Oct, 2023
 * Update 1 (16-Oct,2023): Changed logic for invalid erc20
 */
import { Image } from 'react-bootstrap';
import React, { useEffect, useState } from 'react';
import { useFeeData, useAccount, useNetwork } from 'wagmi';
import { BURN_ADDRESS } from '../../config';
import Web3 from 'web3';
import { RPC } from '../../utils/rpc_chain';

const TokenListObj = ({
  balance,
  address,
  setBrokenTokenCount,
  brokenTokenCount,
  image,
  selectedTokens,
  decimals,
  handleCheckboxChange,
  name,
  symbol
}) => {
  const { chain } = useNetwork();
  const { address: userAdddress } = useAccount();
  const [gasLimit, setGasLimit] = useState(0);
  const [totalFee, setTotalFee] = useState(0);
  const { data } = useFeeData();
  const [isError, setIsError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const web3 = new Web3(RPC[chain.id]);

  useEffect(() => {
    const getGasAmountForContractCall = async () => {
      const contract = new web3.eth.Contract(
        [
          {
            constant: false,
            inputs: [
              {
                name: '_to',
                type: 'address'
              },
              {
                name: '_value',
                type: 'uint256'
              }
            ],
            name: 'transfer',
            outputs: [
              {
                name: '',
                type: 'bool'
              }
            ],
            payable: false,
            stateMutability: 'nonpayable',
            type: 'function'
          },
          {
            constant: true,
            inputs: [],
            name: 'name',
            outputs: [
              {
                name: '',
                type: 'string'
              }
            ],
            payable: false,
            stateMutability: 'view',
            type: 'function'
          }
        ],
        address
      );
      try {
        let estimatedGasLimit = await contract.methods
          .transfer(BURN_ADDRESS, balance)
          .estimateGas({ from: userAdddress });

        setGasLimit(estimatedGasLimit);

        setTotalFee(
          web3.utils.fromWei(BigInt(data?.gasPrice) * BigInt(estimatedGasLimit), 'ether')
        );
        setIsLoading(false);

        return estimatedGasLimit;
      } catch (e) {
        setIsLoading(false);
        setIsError(true);
      }
    };
    if (data !== null) {
      setIsLoading(true);
      getGasAmountForContractCall();
    }
  }, [data]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (isError) {
      localStorage.setItem(
        'brokenTokenCount',
        parseInt(localStorage.getItem('brokenTokenCount')) + 1
      );
      setBrokenTokenCount(brokenTokenCount + 1);
    }
  }, [isError]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      {isError || isLoading ? (
        ''
      ) : (
        <tr key={address}>
          <td>
            <div className="blockchain-icons">
              <Image src={image} className="img-fluid" alt="blockchain icons" />
            </div>
          </td>
          <td>
            <span>{name}</span>
          </td>
          <td>{address}</td>
          <td></td>
          <td>
            <label className="wallet-checkbox">
              <input
                key={address}
                type="checkbox"
                value={address}
                checked={selectedTokens.find((token) => token.address === address)}
                onChange={(e) =>
                  handleCheckboxChange(
                    {
                      feeData: data,
                      gasLimit: gasLimit,
                      totalFee: totalFee,
                      address: e.target.value,
                      balance: balance,
                      decimals: decimals,
                      symbol: symbol,
                      name: name
                    },
                    e.target.checked
                  )
                }
              />

              <span className="checkmark"></span>
            </label>
          </td>
        </tr>
      )}
    </>
  );
};

export default TokenListObj;
