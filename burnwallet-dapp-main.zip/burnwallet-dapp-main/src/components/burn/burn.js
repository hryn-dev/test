/**
 * Display intial Modals according to set condtions.
 * Author: Nauman Sukhera
 * Date: 6 Oct, 2023
 */

import { Modal } from 'react-bootstrap';
import './burn.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faXmark } from '@fortawesome/free-solid-svg-icons';
import React, { useEffect, useState } from 'react';
import HandleTokens from '../web3/handleTokens';
import Lottie from 'react-lottie-player';
import walletLottie from '../../assets/lottie/wallet.json';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import { useAccount } from 'wagmi';

function Burn(props) {
  const handleClose = () => props.setShow(false);
  const [showList, setShowList] = useState(false);
  const [isNext, setIsNext] = useState(false);
  const [showTrnxScreen, setShowTrnxScreen] = useState(false);
  const [modalClass, setModalClass] = useState(
    //handling modal class
    'wallet-modal d-flex align-items-center modal-lg'
  );

  const { isConnected, address } = useAccount();
  useEffect(() => {
    if (!isConnected) {
      handleClose();
    }
  }, [address]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    //handling modal class
    if (showList) {
      setModalClass('wallet-modal assets-list-modal d-flex align-items-center modal-lg');
    } else if (isNext) {
      setModalClass('wallet-modal d-flex align-items-center modal-lg  etn-balance-modal');
    } else if (showTrnxScreen) {
      setModalClass(
        'wallet-modal assets-list-modal d-flex align-items-center modal-lg  etn-balance-modal'
      );
    } else {
      setModalClass('wallet-modal d-flex align-items-center modal-lg');
    }
  }, [isNext, showList, showTrnxScreen]);
  const content = () => {
    switch (true) {
      case !!isConnected: // After wallet is connnected
        return (
          <HandleTokens
            handleClose={handleClose}
            setShowList={setShowList}
            setIsNext={setIsNext}
            setShowTrnxScreen={setShowTrnxScreen}
          />
        );
      default: //In case wallet is not connected
        return (
          <>
            <Modal.Body className="text-center d-flex align-items-center justify-content-center">
              <div className="wallet-modal-content-wrapper">
                <div className="modal-wallet-lottie d-flex align-items-center justify-content-center">
                  <Lottie loop animationData={walletLottie} play />
                </div>
                <div className="wallet-modal-content btn-connect-header">
                  <ConnectButton className="btn btn-blue btn-connect" />
                </div>
              </div>
            </Modal.Body>
          </>
        );
    }
  };
  return (
    <section className="banner-section">
      <>
        <Modal show={props.show} className={modalClass}>
          <Modal.Header>
            {(!isConnected || showList) && (
              <FontAwesomeIcon icon={faXmark} className="cross-icon" onClick={handleClose} />
            )}
          </Modal.Header>
          {content()}
        </Modal>
      </>
    </section>
  );
}

export default Burn;
