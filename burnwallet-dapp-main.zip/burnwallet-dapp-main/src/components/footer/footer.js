import { Container, Image } from 'react-bootstrap';
import footerLogo from '../../assets/images/arhamsoft-logo.svg';
import './footer.css';
import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-top"></div>
      <div className="footer-copyright position-relative">
        <Container>
          <div className="footer-copyright-content d-flex align-items-center justify-content-center">
            <p>©2023 Burn Wallet. All right Reserved.</p>
            <ul className="d-flex align-items-center justify-content-center">
              <li>
                <a href="/">Terms.</a>
              </li>
              <li>
                <a href="/">Privacy.</a>
              </li>
            </ul>
          </div>
        </Container>
        <div className="footer-logo position-absolute">
          <Image src={footerLogo} className="img-fluid" alt="footer logo" />
        </div>
      </div>
    </footer>
  );
};

export default Footer;
