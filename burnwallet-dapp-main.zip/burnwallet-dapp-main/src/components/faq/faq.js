import React from 'react';
import { Accordion, Col, Container, Row } from 'react-bootstrap';
import Lottie from 'react-lottie-player';
import problemLottie from '../../assets/lottie/question.json';
import './faq.css';

const FAQs = () => {
  return (
    <div className="any-question">
      <Container>
        <Row>
          <Col lg="4">
            <div className="any-question-content text-center">
              <h2>FAQs</h2>
              <div className="question-lottie">
                <Lottie loop animationData={problemLottie} play />
              </div>
            </div>
          </Col>
          <Col lg="8">
            <Accordion defaultActiveKey="0" className="any-question-accordion">
              <Accordion.Item eventKey="0">
                <Accordion.Header>
                  Does sending coins/tokens to burnwallet.net reduce the circulating supply of a
                  coin/token ?
                </Accordion.Header>
                <Accordion.Body>
                  {' '}
                  Once a coin/token is sent to burnwallet.net it will not be put back into
                  circulation.
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="1">
                <Accordion.Header>What does burned mean ?</Accordion.Header>
                <Accordion.Body>
                  {' '}
                  Cryptocurrency tokens or coins are burned when they are intentionally and
                  permanently removed from the circulating supply.
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="2">
                <Accordion.Header>
                  Does sending coins/tokens to burnwallet.net help increase a coin/tokens value ?
                </Accordion.Header>
                <Accordion.Body> No</Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="3">
                <Accordion.Header>
                  If I send coins/tokens to burnwallet.net can i get them back ?
                </Accordion.Header>
                <Accordion.Body> No</Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="4">
                <Accordion.Header>
                  Why should i send the unwanted garbage tokens in my wallet to burnwallet.net ?
                </Accordion.Header>
                <Accordion.Body>
                  {' '}
                  The removal of these coins/tokens can help remove the threat these coins/tokens
                  present, help you keep an accurate balance, possibly prevent tax issues, and keep
                  your wallet streamlined.
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="5">
                <Accordion.Header>
                  If i wanted to start a burn campaign should i send coins/tokens to burnwallet.net
                  ?
                </Accordion.Header>
                <Accordion.Body>
                  {' '}
                  You can do as you choose. Just make sure you pay the $10.
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="6">
                <Accordion.Header>
                  What kind of coins/tokens should i send to burnwallet.net ?
                </Accordion.Header>
                <Accordion.Body>
                  {' '}
                  Dusting attacks, rug pull tokens, old token versions, tokens with no value, scam
                  coins/tokens, or tokens you no longer want in circulation{' '}
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="7">
                <Accordion.Header>
                  What happens to coins/tokens when they are sent to burnwallet.net ?
                </Accordion.Header>
                <Accordion.Body>
                  {' '}
                  They are sent to the theoretical lake of fire never to be heard from again
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="8">
                <Accordion.Header>Does burnwallet.net have its own crypto ?</Accordion.Header>
                <Accordion.Body> No</Accordion.Body>
              </Accordion.Item>
            </Accordion>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default FAQs;
