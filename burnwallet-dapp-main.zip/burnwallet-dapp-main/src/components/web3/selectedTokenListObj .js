/**
 * Display tokens
 * Author: Nauman Sukhera
 * Date: 6 Oct, 2023
 */
import React from 'react';
import { Image } from 'react-bootstrap';

import exclamationIcon from '../../assets/images/exclamation-icon.svg';

const SelectedTokenListObj = ({
  name,
  token_address,
  tokenSymbol,
  balance,
  decimals,
  nativeCurrencySymbol,
  totalFee
}) => {
  return (
    <>
      <tr key={token_address}>
        <td>
          <span className="p-0">{name}</span>
        </td>
        <td>
          {balance / 10 ** decimals} {tokenSymbol}
        </td>
        <td className=" td-tooltip">
          <Image src={exclamationIcon} className="img-fluid" alt="exclamation icon" />{' '}
          <span>Estimated gas actual gas may differ</span>
        </td>
        <td className="td-tooltip">
          {parseFloat(totalFee).toFixed(18)} {nativeCurrencySymbol}{' '}
        </td>
      </tr>
    </>
  );
};

export default SelectedTokenListObj;
