import React from 'react';

import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { MORALIS_API, PROJECT_ID, IS_MAINNET, APP_NAME } from './config';
import '@rainbow-me/rainbowkit/styles.css';
import Moralis from 'moralis';
import { getDefaultWallets, RainbowKitProvider } from '@rainbow-me/rainbowkit';

import { configureChains, createConfig, WagmiConfig } from 'wagmi';
import {
  sepolia,
  polygonMumbai,
  arbitrum,
  mainnet,
  polygon,
  avalanche,
  bscTestnet,
  bsc,
  fantom
} from 'wagmi/chains';
import { publicProvider } from 'wagmi/providers/public';

const evmChains = IS_MAINNET
  ? [mainnet, polygon, bsc, avalanche, arbitrum, fantom]
  : [sepolia, polygonMumbai, bscTestnet];
const { chains, publicClient } = configureChains(evmChains, [publicProvider()]);
const { connectors } = getDefaultWallets({
  appName: APP_NAME,
  projectId: PROJECT_ID,
  chains
});

const wagmiConfig = createConfig({
  autoConnect: true,
  connectors,
  publicClient
});
Moralis.start({
  apiKey: MORALIS_API
});
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <WagmiConfig config={wagmiConfig}>
      <RainbowKitProvider chains={chains}>
        <App />
      </RainbowKitProvider>
    </WagmiConfig>
  </React.StrictMode>
);
