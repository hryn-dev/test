import { EvmChain } from '@moralisweb3/common-evm-utils';

export const TOKEN_ADDRESS_MAINNET = {
  [EvmChain.BSC_TESTNET._chainlistData.chainId]: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
  [EvmChain.BSC._chainlistData.chainId]: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
  [EvmChain.ETHEREUM._chainlistData.chainId]: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2',
  [EvmChain.SEPOLIA._chainlistData.chainId]: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2',
  [EvmChain.POLYGON._chainlistData.chainId]: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
  [EvmChain.MUMBAI._chainlistData.chainId]: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
  [EvmChain.AVALANCHE_TESTNET._chainlistData.chainId]: '0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7',
  [EvmChain.AVALANCHE._chainlistData.chainId]: '0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7',
  [EvmChain.FANTOM._chainlistData.chainId]: '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83',
  [EvmChain.FANTOM_TESTNET._chainlistData.chainId]: '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83',
  [EvmChain.ARBITRUM._chainlistData.chainId]: '0x912CE59144191C1204E64559FE8253a0e49E6548'
};
