/**
 * User token holding table.
 * Author: Nauman Sukhera
 * Date: 15 Nov, 2023
 */
import { Table } from 'react-bootstrap';
import TokenListObj from './web3/tokenListObj';

export const TokenListTable = ({
  userTokenHoldings,
  ethereumIcon,
  handleCheckboxChange,
  selectedTokens,
  setBrokenTokenCount,
  brokenTokenCount
}) => {
  return (
    <div className="table-responsive mb-4">
      <Table className="wallet-modal-table mb-2">
        <tbody>
          {userTokenHoldings.map((token) => (
            <TokenListObj
              key={token.token_address}
              name={token.name}
              balance={token.balance}
              decimals={token.decimals}
              symbol={token.symbol}
              address={token.token_address}
              image={token.logo || ethereumIcon}
              handleCheckboxChange={handleCheckboxChange}
              selectedTokens={selectedTokens}
              setBrokenTokenCount={setBrokenTokenCount}
              brokenTokenCount={brokenTokenCount}
            />
          ))}
        </tbody>
      </Table>
    </div>
  );
};
