import { EvmChain } from '@moralisweb3/common-evm-utils';

export const RPC = {
  [EvmChain.BSC_TESTNET._chainlistData.chainId]: 'https://data-seed-prebsc-1-s1.binance.org:8545/',
  [EvmChain.BSC._chainlistData.chainId]: 'https://bsc-dataseed1.binance.org/',
  [EvmChain.ETHEREUM._chainlistData.chainId]:
    'https://mainnet.infura.io/v3/8d8050eb830b49a0b5f17595bc398dda',
  [EvmChain.SEPOLIA._chainlistData.chainId]:
    'https://sepolia.infura.io/v3/8d8050eb830b49a0b5f17595bc398dda',
  [EvmChain.POLYGON._chainlistData.chainId]:
    'https://polygon-mainnet.infura.io/v3/8d8050eb830b49a0b5f17595bc398dda',
  [EvmChain.MUMBAI._chainlistData.chainId]:
    'https://polygon-mumbai.infura.io/v3/8d8050eb830b49a0b5f17595bc398dda',
  [EvmChain.AVALANCHE_TESTNET._chainlistData.chainId]:
    'https://avalanche-fuji.infura.io/v3/8d8050eb830b49a0b5f17595bc398dda',
  [EvmChain.AVALANCHE._chainlistData.chainId]:
    'https://avalanche-mainnet.infura.io/v3/8d8050eb830b49a0b5f17595bc398dda',
  [EvmChain.FANTOM._chainlistData.chainId]: 'https://rpcapi.fantom.network',
  [EvmChain.FANTOM_TESTNET._chainlistData.chainId]: 'https://rpc.testnet.fantom.network',
  [EvmChain.ARBITRUM._chainlistData.chainId]:
    'https://arbitrum-mainnet.infura.io/v3/8d8050eb830b49a0b5f17595bc398dda'
};
