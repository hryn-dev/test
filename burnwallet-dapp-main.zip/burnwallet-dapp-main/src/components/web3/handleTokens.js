/**
 * Get's  user's token holdings, display Modals according to set condtions.
 * Handle native price
 * Author: Nauman Sukhera
 * Date: 6 Oct, 2023
 * Update 1 (13 Oct, 2023):Removed confirmation and balance screen modal.
 *                         Added screen for estimated gas and user selected tokens with total required funds.
 * Update 2 (16-Oct,2023) :Handle wallet change added alert for it. Changed logic for invalid erc20.
 *                         Handle Chain change added alert for it and close modal on change chain.
 * updtae 3 (18-Oct-2023) :Added Sorting of tokens.
 * updtae 4 (15-Nov-2023) :Move table to component.
 */
import { Image } from 'react-bootstrap';
import { useAccount, useBalance, useNetwork, useDisconnect } from 'wagmi';
import { Button, Table, Modal } from 'react-bootstrap';
import React, { useEffect, useState, useRef } from 'react';
import Moralis from 'moralis';
import Lottie from 'react-lottie-player';
import Swal from 'sweetalert2';

import ethereumIcon from '../../assets/images/ethereum-icon.png';
import sendLottie from '../../assets/lottie/send.json';
import BurnTransactionFee from './burnTransactionFee';
import SelectedTokenListObj from './selectedTokenListObj ';
import exclamationIcon from '../../assets/images/exclamation-icon.svg';
import { LOADING_DELAY, RETRIEVE_DELAY } from '../../config';
import { TokenListTable } from '../tokenListTable';

const HandleTokens = (props) => {
  const { chain } = useNetwork();
  const { disconnect } = useDisconnect();
  const { isConnected, address } = useAccount();
  const { data } = useBalance({
    address: address
  });
  const [userTokenHoldings, setUserTokenHoldings] = useState();
  const [nativePrice, setNativePrice] = useState();
  const [brokenTokenCount, setBrokenTokenCount] = useState();
  const [selectedTokens, setSelectedTokens] = useState([]);
  const [fee, setFee] = useState(0);
  const [burnFeeGas, setBurnFeeGas] = useState(0);
  const [dollarFee, setDollarFee] = useState(0);
  const [execute, setExecute] = useState(Boolean);
  const [callPrice, setCallPrice] = useState(true);
  const [showList, setShowList] = useState(false);
  const [estimatedGasScreen, setEstimatedGasScreen] = useState(false);
  const [totalGasFee, setTotalGasFee] = useState(0.0);
  const [isEmpty, setIsEmpty] = useState(false);
  const [retriveCompleted, setRetriveCompleted] = useState(false);
  const [allowed, setAllowed] = useState(false);
  const [showTrnxScreen, setShowTrnxScreen] = useState(false);
  const previousChain = useRef(null);
  const previousAddress = useRef(null);
  const [showCongrats, setShowCongrats] = useState(false);
  const [loaderMsg, setLoaderMsg] = useState('Assets');
  const handleCheckboxChange = (value, isChecked) => {
    if (isChecked) {
      // Add the value to the selectedValues array
      setSelectedTokens([
        ...selectedTokens,
        {
          name: value.name,
          address: value.address,
          totalFee: value.totalFee,
          gasLimit: value.gasLimit,
          balance: value.balance,
          decimals: value.decimals,
          symbol: value.symbol,
          feeData: value.feeData
        }
      ]);
    } else {
      // Remove the value from the selectedValues array
      setSelectedTokens(selectedTokens.filter((token) => token.address !== value.address));
    }
  };

  const handleNext = async () => {
    if (selectedTokens.length > 0) {
      setShowList(false);
      if (parseFloat(data?.formatted) >= parseFloat(fee) + parseFloat(totalGasFee)) {
        setAllowed(true);
      }
      setLoaderMsg('');
      await new Promise((resolve) => setTimeout(resolve, LOADING_DELAY)); // extra wait 2 seconds;

      setEstimatedGasScreen(true);
    }
  };
  useEffect(() => {
    if (previousChain.current !== chain.id && previousChain.current != null) {
      //Check for network chain change
      Swal.fire({
        title: 'Network Chain Change Detected!',
        html: "We regret to inform you that a change in network is not supported at this stage.<br>To proceed, you'll need to start your transaction again.<br>We appreciate your understanding and cooperation.",
        icon: 'warning',
        confirmButtonColor: '#808091',
        confirmButtonText: 'Ok'
      });

      props.handleClose();
    }

    previousChain.current = chain.id;
  }, [chain]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const retrive = async () => {
      const response = await Moralis.EvmApi.token.getWalletTokenBalances({
        address,
        chain: chain.id
      });
      if (response.toJSON().length === 0) {
        setIsEmpty(true);
      }

      setUserTokenHoldings(response.toJSON().sort((a, b) => a.name.localeCompare(b.name)));
      await new Promise((resolve) => setTimeout(resolve, RETRIEVE_DELAY)); // extra wait 3 seconds;
      setRetriveCompleted(true);
    };
    if (previousAddress.current !== address && previousAddress.current != null) {
      Swal.fire({
        title: 'Wallet Address Change Detected!',
        html: "We've detected a change in your wallet address.<br>Please note that all future transactions will be associated with the new wallet address. Ensure it's accurate and up-to-date to avoid any issues.<br>If this change was made intentionally, no further action is required. If not, please review your account settings.<br>Thank you for your attention.",
        icon: 'warning',
        confirmButtonColor: '#808091',
        confirmButtonText: 'Ok'
      });
      // props.handleClose();
    } else if (address) {
      localStorage.setItem('brokenTokenCount', 0);
      setBrokenTokenCount(0);
      setShowTrnxScreen(false);
      setEstimatedGasScreen(false);
      setExecute(false);
      setShowCongrats(false);
      retrive();
    }
    previousAddress.current = address;
  }, [address]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    props.setShowList(showList);
  }, [showList]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    props.setShowTrnxScreen(showTrnxScreen);
    props.setIsNext(estimatedGasScreen);
  }, [estimatedGasScreen]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (showTrnxScreen) {
      setExecute(true);
    }
  }, [showTrnxScreen]);
  useEffect(() => {
    if (
      parseInt(localStorage.getItem('brokenTokenCount')) === userTokenHoldings?.length &&
      retriveCompleted
    ) {
      setShowList(false);
      setIsEmpty(true);
    } else if (retriveCompleted) {
      setShowList(true);
    }
  }, [brokenTokenCount, retriveCompleted]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    let fee = 0.0;
    selectedTokens.map((token) => {
      fee += parseFloat(token.totalFee);
      return <></>;
    });
    setTotalGasFee((fee + parseFloat(burnFeeGas)).toFixed(18));
  }, [selectedTokens]); // eslint-disable-line react-hooks/exhaustive-deps

  let content;

  switch (true) {
    case !isConnected:
      content = 'Not Connected to wallet';
      break;
    case estimatedGasScreen:
      // estimated gas for transfer

      content = (
        <Modal.Body className="text-center d-flex align-items-center justify-content-center">
          <div className="wallet-modal-content-wrapper">
            <div className="wallet-modal-content-wrapper eth-balance-content-wrapper">
              <div className="table-responsive mb-4">
                <Table className="wallet-modal-table selected-token-table mb-2">
                  <thead>
                    <tr key={'table head'}>
                      <th>Name</th>
                      <th>Amount</th>
                      <th></th>
                      <th>Gas Cost</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedTokens.map((token) => (
                      <SelectedTokenListObj
                        key={token.token_address}
                        totalGasFee={totalGasFee}
                        setTotalGasFee={setTotalGasFee}
                        name={token.name}
                        balance={token.balance}
                        decimals={token.decimals}
                        tokenSymbol={token.symbol}
                        address={token.address}
                        totalFee={token.totalFee}
                        nativeCurrencySymbol={chain.nativeCurrency.symbol}
                      />
                    ))}
                    <tr key={'fee'}>
                      <td>Fee</td>
                      <td>
                        {' '}
                        {fee} {chain.nativeCurrency.symbol}
                      </td>
                      <td className="td-tooltip">
                        <Image src={exclamationIcon} className="img-fluid" alt="exclamation icon" />{' '}
                        <span>Estimated gas actual gas may differ</span>
                      </td>
                      <td className="td-tooltip">
                        {parseFloat(burnFeeGas)?.toFixed(18)} {chain.nativeCurrency.symbol}
                      </td>
                    </tr>
                    <tr key={'cost'}>
                      <td></td>
                      <td className="estimation-td">Estimated Total Gas cost </td>
                      <td className="estimation-td td-tooltip">
                        <Image src={exclamationIcon} className="img-fluid" alt="exclamation icon" />{' '}
                        <span>Estimated gas actual gas may differ</span>
                      </td>
                      <td className="estimation-td td-tooltip">
                        {(parseFloat(totalGasFee) + parseFloat(burnFeeGas)).toFixed(18)}{' '}
                        {chain.nativeCurrency.symbol}
                      </td>
                    </tr>
                    <tr key={'Estimated total'}>
                      <td></td>
                      <td className="estimation-td">Total </td>
                      <td className="estimation-td td-tooltip">
                        <Image src={exclamationIcon} className="img-fluid" alt="exclamation icon" />{' '}
                        <span>Estimated total actual total may differ</span>
                      </td>
                      <td className="estimation-td td-tooltip">
                        {(
                          parseFloat(totalGasFee) +
                          parseFloat(fee) +
                          parseFloat(burnFeeGas)
                        ).toFixed(18)}{' '}
                        {chain.nativeCurrency.symbol}
                      </td>
                    </tr>
                    <tr key={'total dollar'}>
                      <td></td>
                      <td className="estimation-td">Total ($) </td>
                      <td className="estimation-td td-tooltip">
                        <Image src={exclamationIcon} className="img-fluid" alt="exclamation icon" />{' '}
                        <span>Estimated total actual total may differ</span>
                      </td>
                      <td className="estimation-td td-tooltip">
                        {'$ '}
                        {(
                          (parseFloat(totalGasFee) + parseFloat(fee) + parseFloat(burnFeeGas)) *
                          nativePrice
                        ).toFixed(6)}{' '}
                      </td>
                    </tr>
                  </tbody>
                </Table>
              </div>

              <div className="eth-buttons-wrapper d-flex justify-content-between mb-3">
                <div className="etn-button-wrapper p-0 me-sm-3 me-0">
                  <Button className="btn-red" onClick={props.handleClose}>
                    Cancel
                  </Button>
                </div>
                <div className="d-flex selected-token-btn-wrapper">
                  <div className="etn-button-wrapper p-0 me-sm-3 me-3">
                    <Button
                      className="btn-blue btn-gray-light"
                      onClick={() => {
                        setShowList(true);
                        setBrokenTokenCount(0);
                        setEstimatedGasScreen(false);
                        setTotalGasFee(0.0);
                      }}
                    >
                      Previous
                    </Button>
                  </div>
                  <div className="etn-button-wrapper p-0">
                    <Button
                      className="btn-green btn-gray"
                      disabled={!allowed}
                      onClick={() => {
                        Swal.fire({
                          title: 'Are you sure to proceed ?',
                          text: 'Once you proceed, the transaction will be finalized based on the information provided. Double-check your details before continuing.',
                          icon: 'warning',
                          showCancelButton: true,
                          confirmButtonColor: '#5C8E00',
                          cancelButtonColor: '#80808091',
                          confirmButtonText: 'Proceed',
                          cancelButtonText: 'Cancel'
                        }).then((result) => {
                          if (result.isConfirmed) {
                            setShowTrnxScreen(true);
                            setShowList(false);
                            setEstimatedGasScreen(false);
                          }
                        });
                      }}
                    >
                      Proceed
                    </Button>
                  </div>
                </div>
              </div>
              <p className="mb-0 text-danger">
                {!allowed ? 'Insufficient Balance in account' : ''}
              </p>
            </div>
          </div>
        </Modal.Body>
      );
      break;

    case userTokenHoldings && showList && userTokenHoldings.length > 0: //User's tokens Screen
      content = (
        <Modal.Body className="">
          <div className="wallet-modal-content-wrapper">
            <div className="wallet-modal-content mb-4">
              <h3>List of Assets</h3>
            </div>
            <TokenListTable
              userTokenHoldings={userTokenHoldings}
              ethereumIcon={ethereumIcon}
              handleCheckboxChange={handleCheckboxChange}
              selectedTokens={selectedTokens}
              setBrokenTokenCount={setBrokenTokenCount}
              brokenTokenCount={brokenTokenCount}
            />
            <div className="text-end mb-4">Fee {dollarFee}$</div>
            <div className="wallet-content-charges text-end d-flex align-items-center justify-content-end">
              {selectedTokens.length > 0 ? (
                <Button
                  className="btn-green"
                  onClick={() => {
                    handleNext();
                  }}
                >
                  Next
                </Button>
              ) : (
                ''
              )}
            </div>
          </div>
        </Modal.Body>
      );
      break;
    case showTrnxScreen: // Transaction screen charging fee and burning tokens . Trigger by confirmation screen and handle by BurnTransactionFee comp
      content = <></>;
      break;
    case showCongrats:
      content = (
        <Modal.Body className="text-center d-flex align-items-center justify-content-center">
          <div className="wallet-modal-content-wrapper">
            <div className="wallet-modal-content mb-4">
              <h3 className="mb-4">Successfully Done</h3>
              <p className="mb-0">
                Congratulations on successfully completing the wallet burn process! <br /> Your
                achievement is a testament to your commitment and diligence.
              </p>
            </div>
            <div className="etn-button-wrapper">
              <Button className="btn-green mx-auto" onClick={props.handleClose}>
                Done
              </Button>
            </div>
          </div>
        </Modal.Body>
      );
      break;
    case isEmpty: //Wallet empty no tokens founds
      content = (
        <Modal.Body className="text-center d-flex align-items-center justify-content-center">
          <div className="wallet-modal-content-wrapper">
            <div className="wallet-modal-content mb-4">
              <h3 className="mb-4">Tokens Not Found </h3>
              <p className="mb-0"></p>
            </div>
            <div className="etn-button-wrapper">
              <Button
                className="btn-red mx-auto"
                onClick={() => {
                  props.handleClose();
                  disconnect();
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        </Modal.Body>
      );
      break;
    default: //Loading screen
      content = (
        <Modal.Body className="text-center d-flex align-items-center justify-content-center">
          <div>
            <div className="modal-wallet-lottie modal-send-lottie d-flex align-items-center justify-content-center">
              <Lottie loop animationData={sendLottie} play />
            </div>
            <div className="wallet-modal-content">
              <h3>Loading {loaderMsg}</h3>
            </div>
          </div>
        </Modal.Body>
      );
  }

  return (
    <>
      {content}
      <BurnTransactionFee
        setNativePrice={setNativePrice}
        nativePrice={nativePrice}
        selectedTokens={selectedTokens}
        userTokenHoldings={userTokenHoldings}
        setExecute={setExecute}
        fee={fee}
        setFee={setFee}
        execute={execute}
        setCallPrice={setCallPrice}
        callPrice={callPrice}
        handleClose={props.handleClose}
        setShowCongrats={setShowCongrats}
        dollarFee={dollarFee}
        setDollarFee={setDollarFee}
        setShowTrnxScreen={setShowTrnxScreen}
        setBurnFeeGas={setBurnFeeGas}
      />
    </>
  );
};

export default HandleTokens;
