import React from 'react';
import { Image, Container } from 'react-bootstrap';
import worksImg from '../../assets/images/how-works-img.png';
import worksMobileImg from '../../assets/images/how-works-mobile-img.png';
import './howworks.css';

const HowWorks = () => {
  return (
    <div className="how-works">
      <Container>
        <div className="how-works-content">
          <div className="how-works-heading text-center">
            <h2>How it Works</h2>
          </div>
          <div className="how-works-img d-md-block d-none">
            <Image src={worksImg} className="img-fluid" alt="how works img" />
          </div>
          <div className="how-works-mobile-img d-md-none d-block">
            <Image src={worksMobileImg} className="img-fluid" alt="how works img" />
          </div>
        </div>
      </Container>
    </div>
  );
};

export default HowWorks;
