/**
 * Refister Transaction send api to backend .
 * Author: Nauman Sukhera
 * Date: 15 Nov, 2023
 */
import axios from 'axios';

import { API_URL } from '../config';
export const registerTransaction = (
  data,
  addresses,
  chain,
  fee,
  address,
  dollarFee,
  localNativePrice
) => {
  axios.post(`${API_URL}/transaction/add`, {
    transactionHash: data?.hash,
    tokens: addresses,
    chainID: chain.id,
    chainName: chain.name,
    userWalletAddress: address,
    feeInNative: fee,
    feeInDollars: dollarFee.toString(),
    nativePrice: localNativePrice
  });
};
