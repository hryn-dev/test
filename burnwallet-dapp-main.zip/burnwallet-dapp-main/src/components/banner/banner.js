//* Update 1 (6 Oct, 2023): ,
//* Added support for buttons and set Modal controls.
//* Nauman Sukhera

import { Container, Row, Col, Button, Image } from 'react-bootstrap';
import bannerImg from '../../assets/images/banner-col-img.png';
import { useEffect, useState } from 'react';
import './banner.css';
import Burn from '../burn/burn';
import React from 'react';

const Banner = ({ setShowModal, showModal }) => {
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  useEffect(() => {
    if (showModal === true) {
      handleShow();
      setShowModal(false);
    }
  }, [showModal]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <section className="banner-section">
      <Container>
        <Row className="align-items-center">
          <Col lg="5" className="order-lg-first order-last">
            <div className="banner-content">
              <span className="sub-title">Welcome to</span>
              <h1>Burn Wallet</h1>
              <h4>Where the fire never goes out.</h4>
              <p>
                Take the dusting attacks, rug pull tokens, old token versions, and throw them into
                the blazing furnace. Where there will be weeping and gnashing of teeth, clean out
                your wallet!!!
              </p>
              <Button className="btn-outline" onClick={handleShow}>
                Try Now
              </Button>
            </div>
          </Col>
          <Col lg="7" className="order-lg-last order-first">
            <div className="banner-img-wrapper position-relative">
              <div className="video">
                <video poster="/images/intro-poster.png" autoPlay controls playsInline loop>
                  <source src="/video/video.webm" type="video/webm" />
                </video>
              </div>
              <div className="banner-img">
                <Image src={bannerImg} className="img-fluid" alt="banner-img" />
              </div>
              <Button className="btn-blue" onClick={handleShow}>
                Burn Token
              </Button>
            </div>
          </Col>
        </Row>
      </Container>
      <Burn show={show} setShow={setShow}></Burn>
    </section>
  );
};

export default Banner;
