import { Container, Navbar, Nav, Image } from 'react-bootstrap';
import './header.css';
import Logo from '../../assets/images/logo.png';
import togglerIcon from '../../assets/images/bars.svg';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import React from 'react';

const Header = ({ handleNavigation }) => {
  return (
    <header className="header">
      <Navbar expand="lg">
        <Container className="position-relative">
          <Navbar.Brand href="#home" className="logo">
            <img src={Logo} alt="Logo" className="img-fluid" />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav">
            <div className="toggler-icon">
              <Image src={togglerIcon} className="img-fluid" alt="toggler icon" />
            </div>
          </Navbar.Toggle>
          <div className="header-items d-flex align-items-center">
            <Navbar.Collapse id="basic-navbar-nav" className="header-list-wrapper">
              <Nav className="ms-auto header-list">
                <Nav.Link onClick={() => handleNavigation('about')}>About Burn Wallet </Nav.Link>
                <Nav.Link onClick={() => handleNavigation('problem')}>Problem</Nav.Link>
                <Nav.Link onClick={() => handleNavigation('solution')}>Solution</Nav.Link>
              </Nav>
            </Navbar.Collapse>
            <div className="other-btns btn-connect-header d-flex align-items-center">
              <ConnectButton className="btn btn-blue btn-connect" showBalance={false} />
            </div>
          </div>
        </Container>
      </Navbar>
    </header>
  );
};

export default Header;
