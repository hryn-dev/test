import React from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import Lottie from 'react-lottie-player';
import problemLottie from '../../assets/lottie/problem.json';
import './problem.css';

const Problem = () => {
  return (
    <section className="problem">
      <Container>
        <Row className="align-items-center">
          <Col lg="6" className="order-lg-first order-last">
            <div className="problem-content">
              <h2 className="text-orange">Problem</h2>
              <p className="mb-md-4 mb-3">
                If you have ever checked your crypto wallet on a chain explorer you would have
                probably discovered various tokens sitting in your wallet that you don’t remember
                buying. Some of these can come from airdrops but others are the result of dusting
                attacks. In a dusting attack rogue developers will create a token contract that
                prohibits anyone except whitelisted wallet addresses from selling the token. Because
                these rogue token creators have the ability to airdrop their tokens to a wide range
                of addresses, unsolicited tokens can appear in your wallet without your knowledge.
                The problem is there is NO way to stop this. Once these tokens are in your wallet
                there is nowhere to discard them as exchanges (CEX or DEX) won't take them.
              </p>
              <p>
                In addition you may have fallen victim to rug pulls which leave useless tokens
                cluttering your wallet. Or as tokens have rebranded you now have old token versions
                which only confuse balances, can cause tax complications, and have no practical
                place in your wallet.
              </p>
            </div>
          </Col>
          <Col lg="6" className="order-lg-last order-first">
            <div className="problem-lottie-bg">
              <div className="problem-lottie">
                <Lottie loop animationData={problemLottie} play />
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default Problem;
