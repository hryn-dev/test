/**
 * Home page.
 * Author: Nauman Sukhera
 * Date: 6 Oct, 2023
 */

import Banner from '../components/banner/banner';
import HowWorks from '../components/howWorks/howWorks';
import FAQs from '../components/faq/faq';
import Problem from '../components/problem/problem';
import Solution from '../components/solution/solution';
import WhatsWallet from '../components/whatsWallet/whatsWallet';
import Footer from '../components/footer/footer';
import Header from '../components/header/header';
import React, { useState } from 'react';
import Contact from '../components/contact/contact';
const Home = () => {
  const [activeSection, setActiveSection] = useState('');
  const [showModal, setShowModal] = useState(false);
  const handleNavigation = (sectionId) => {
    setActiveSection(sectionId);

    // Get the target element
    const targetElement = document.getElementById(sectionId);

    if (targetElement) {
      targetElement.scrollIntoView({
        behavior: 'smooth',
        block: 'end',
        inline: 'nearest'
      });
    }
  };
  return (
    <>
      <Header handleNavigation={handleNavigation} />
      <Banner showModal={showModal} setShowModal={setShowModal} />
      <section id="about" className={activeSection === 'about' ? 'active' : ''}>
        <WhatsWallet />
      </section>
      <section id="problem" className={activeSection === 'problem' ? 'active' : ''}>
        <Problem />
      </section>

      <section id="solution" className={activeSection === 'solution' ? 'active' : ''}>
        <Solution setShowModal={setShowModal} />
      </section>
      <HowWorks />
      <FAQs />
      <Contact />
      <Footer />
    </>
  );
};

export default Home;
