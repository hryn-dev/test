export const BURN_ADDRESS = '0xBf19E1B8893CA50c9Cd3aF8b6a5a0a24124cec89'; //process.env.REACT_APP_BURN_ADDRESS;
export const FEE_ADDRESS = '0xBf19E1B8893CA50c9Cd3aF8b6a5a0a24124cec89'; //process.env.REACT_APP_FEE_ADDRESS;
export const PROJECT_ID = process.env.REACT_APP_RAINBOW_KIT_PROJECT_ID;
export const APP_NAME = 'dapp'; //Rainbow kit
export const MORALIS_API = process.env.REACT_APP_MORALIS_API_KEY;
export const IS_MAINNET = process.env.REACT_APP_CHAIN_MAINNET === 'true' ? true : false;
export const LOADING_DELAY = process.env.REACT_APP_LOADING_DELAY;
export const RETRIEVE_DELAY = process.env.REACT_APP_RETRIEVE_DELAY;
export const EMAIL_API = process.env.REACT_APP_EMAIL_API_URL;
export const CUSTOMER_SERVICE_EMAIL = process.env.REACT_APP_CUSTOMER_SERVICE_EMAIL;
export const TOAST_TIMMER = process.env.REACT_APP_TOAST_TIMMER;
export const FACEBOOK_HANDLE = process.env.REACT_APP_FACEBOOK_HANDLE;
export const INSTAGRAM_HANDLE = process.env.REACT_APP_INSTAGRAM_HANDLE;
export const TWITTER_HANDLE = process.env.REACT_APP_TWITTER_HANDLE;
export const TELEGRAM_HANDLE = process.env.REACT_APP_TELEGRAM_HANDLE;
export const API_URL = process.env.REACT_APP_API_URL;
export const ABI = [
  {
    constant: false,
    inputs: [
      {
        name: '_to',
        type: 'address'
      },
      {
        name: '_value',
        type: 'uint256'
      }
    ],
    name: 'transfer',
    outputs: [
      {
        name: '',
        type: 'bool'
      }
    ],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function'
  },
  {
    constant: true,
    inputs: [],
    name: 'name',
    outputs: [
      {
        name: '',
        type: 'string'
      }
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function'
  }
];
