# 🔥🌐 BurnWallet 🌐🔥

Burnwallet admin panel 
A admin panel to mange this site avialable https://github.com/asoftPHPteam/burnwallet-admin


## ✨  Features 

### 🌐 Multi wallet support .
Including MetaMask, Rainbow, and Coinbase.

### 📊 List All User's ERC-20 Tokens on Selected Chain
Effortlessly view and manage all user's ERC-20 tokens on the chosen blockchain.

### 🧮 Calculate Burn Fee
Precisely calculate burn fees based on primary and secondary fee structures. Applies the primary fee to the first token and secondary fees to all others.

### 🔥 Burn Token

Initiate token burning, transferring the tokens to the admin's wallet on the selected blockchain after the burn fee is paid.

### 🔄 claim refund 

In the event of an unsuccessful transaction, users can request a refund through the admin.


### 📧 Inovice 
Following a successful burn, users receive an invoice via email for their records.


### 📬 Admin contact throught contact us 
Enable communication with the admin via the "Contact Us" feature for seamless assistance.


## ⛓️Multichain Support:

* **ETHEREUM**

* **Binance**

* **POLYGON**

* **AVALANCHE**

* **FANTOM**



## 🚀  Operational Guidelines

In the project directory, you can run:

### 📦 Install Packages

At the root directory of the application, run the following command to install packages:

npm install

### Configure app

Add .env file at root of the project. Sample values available in .env.example file.


### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.


### `npm run build`

Compiles the app for production into the build folder.
Effectively packages React in production mode and streamlines the build for optimal performance.

The build undergoes minification, and the filenames incorporate unique hashes.
Application is now prepared for deployment

