/**
 * Email from .
 * Author: Nauman Sukhera
 * Date: 15 Nov, 2023
 */
import { Form } from 'react-bootstrap';

export const EmailFrom = ({ handleEmailChange }) => {
  return (
    <Form className="wallet-modal-form">
      <Form.Group
        className="mb-4 input-wrapper d-flex align-items-center justify-content-between"
        controlId="formBasicEmail"
      >
        <Form.Label>Add email (optional)</Form.Label>
        <Form.Control type="email" onChange={handleEmailChange} />
      </Form.Group>
    </Form>
  );
};
