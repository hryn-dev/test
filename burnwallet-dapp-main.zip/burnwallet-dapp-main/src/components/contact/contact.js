/*
 * Collect's user information and send email to customer service.
 * Author: Nauman Sukhera
 * Date: 16 Oct, 2023
 */
import React, { useState } from 'react';
import { Col, Container, Row, Button } from 'react-bootstrap';
import './contact.css';
import axios from 'axios';
import {
  API_URL,
  TOAST_TIMMER,
  FACEBOOK_HANDLE,
  INSTAGRAM_HANDLE,
  TWITTER_HANDLE,
  TELEGRAM_HANDLE
} from '../../config';
import Swal from 'sweetalert2';

const Contact = () => {
  const [userEmail, setUserEmail] = useState('');
  const [userName, setUserName] = useState('');
  const [emailError, setEmailError] = useState(false);
  const [userMessage, setUserMessage] = useState('');
  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: TOAST_TIMMER,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    }
  });
  function sendEmail() {
    // Email  Template
    // let htmlContent = `<div>Name: ${userName}</div><div>Email: ${userEmail}</div><div>Message: ${userMessage}</div>`;

    // const formData = new FormData();
    // formData.append("send_email", 1);
    // formData.append("to_email", CUSTOMER_SERVICE_EMAIL);
    // formData.append("subject", "Contact request");
    // formData.append("body_html", htmlContent);

    // axios
    //   .post(EMAIL_API, formData)
    //   .then((response) => {
    //     setUserEmail("");
    //     setUserName("");
    //     setUserMessage("");
    //     Toast.fire({
    //       icon: "success",
    //       title: "Form submitted successfully!",
    //     });
    //   })
    //   .catch((error) => {
    //     Toast.fire({
    //       icon: "error",
    //       title: "Error in submitting the form!",
    //     });
    //   });

    axios
      .post(API_URL + '/contact/create', {
        name: userName,
        email: userEmail,
        message: userMessage
      })
      .then(() => {
        setUserEmail('');
        setUserName('');
        setUserMessage('');
        Toast.fire({
          icon: 'success',
          title: 'Form submitted successfully!'
        });
      })
      .catch((err) => {
        alert('Error!');
        console.log('Error is ', err);
      });
  }
  const handleSubmit = () => {
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    if (userName === '' || userMessage?.length <= 1) {
      Toast.fire({
        icon: 'error',
        title: 'All feilds are required!'
      });
    } else if (!emailRegex.test(userEmail)) {
      Toast.fire({
        icon: 'error',
        title: 'Invalid Email!'
      });
    } else {
      sendEmail();
    }
  };

  return (
    <div className="contact">
      <Container>
        <Row>
          <Col lg="4">
            <div className="contact-content">
              <span className="pre-heading">Still you have any question?</span>
              <h2>Contact us</h2>
              <div className="social-links-wrapper">
                <h4>Social Connect</h4>
                <ul>
                  <li>
                    <a href={FACEBOOK_HANDLE} target="_blank" rel="noreferrer">
                      <svg width="11.046" height="22.092" viewBox="0 0 11.046 22.092">
                        <path
                          id="Icon_awesome-facebook-f"
                          data-name="Icon awesome-facebook-f"
                          d="M11.931,12.427l.573-4H8.923V5.834a1.937,1.937,0,0,1,2.1-2.16h1.628V.27A18.577,18.577,0,0,0,9.765,0C6.816,0,4.888,1.915,4.888,5.381V8.429H1.609v4H4.888v9.665H8.923V12.427Z"
                          transform="translate(-1.609)"
                          fill="#fff"
                        />
                      </svg>
                    </a>
                  </li>
                  <li>
                    <a href={INSTAGRAM_HANDLE} target="_blank" rel="noreferrer">
                      <svg width="20.861" height="20.861" viewBox="0 0 20.861 20.861">
                        <g
                          id="Icon_feather-instagram"
                          data-name="Icon feather-instagram"
                          transform="translate(-2 -2)"
                        >
                          <path
                            id="Path_147"
                            data-name="Path 147"
                            d="M7.715,3h9.431a4.715,4.715,0,0,1,4.715,4.715v9.431a4.715,4.715,0,0,1-4.715,4.715H7.715A4.715,4.715,0,0,1,3,17.146V7.715A4.715,4.715,0,0,1,7.715,3Z"
                            fill="none"
                            stroke="#fff"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                          />
                          <path
                            id="Path_148"
                            data-name="Path 148"
                            d="M22.3,16.324a5.144,5.144,0,1,1-4.334-4.334A5.144,5.144,0,0,1,22.3,16.324Z"
                            transform="translate(-4.747 -4.679)"
                            fill="none"
                            stroke="#fff"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                          />
                          <path
                            id="Path_149"
                            data-name="Path 149"
                            d="M26.25,9.75h0"
                            transform="translate(-8.633 -2.506)"
                            fill="none"
                            stroke="#fff"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                          />
                        </g>
                      </svg>
                    </a>
                  </li>
                  <li>
                    <a href={TWITTER_HANDLE} target="_blank" rel="noreferrer">
                      <svg viewBox="0,0,256,256" width="28px" height="28px">
                        <g
                          fill="#ffffff"
                          fill-rule="nonzero"
                          stroke="none"
                          stroke-width="1"
                          stroke-linecap="butt"
                          stroke-linejoin="miter"
                          stroke-miterlimit="10"
                          stroke-dasharray=""
                          stroke-dashoffset="0"
                          font-family="none"
                          font-weight="none"
                          font-size="none"
                          text-anchor="none"
                        >
                          <g transform="scale(5.12,5.12)">
                            <path d="M6.91992,6l14.2168,20.72656l-14.9082,17.27344h3.17773l13.13867,-15.22266l10.44141,15.22266h10.01367l-14.87695,-21.6875l14.08008,-16.3125h-3.17578l-12.31055,14.26172l-9.7832,-14.26172z"></path>
                          </g>
                        </g>
                      </svg>
                    </a>
                  </li>
                  <li>
                    <a href={TELEGRAM_HANDLE} target="_blank" rel="noreferrer">
                      <svg viewBox="0,0,256,256" width="28px" height="28px">
                        <g
                          fill="#ffffff"
                          fill-rule="nonzero"
                          stroke="none"
                          stroke-width="1"
                          stroke-linecap="butt"
                          stroke-linejoin="miter"
                          stroke-miterlimit="10"
                          stroke-dasharray=""
                          stroke-dashoffset="0"
                          font-family="none"
                          font-weight="none"
                          font-size="none"
                          text-anchor="none"
                        >
                          <g transform="scale(8,8)">
                            <path d="M26.07031,3.99609c-0.33594,0.01563 -0.65234,0.11328 -0.93359,0.22266h-0.00391c-0.28516,0.11328 -1.64062,0.68359 -3.69922,1.54688c-2.05859,0.86719 -4.73047,1.99219 -7.38281,3.10938c-5.29687,2.23047 -10.50391,4.42578 -10.50391,4.42578l0.0625,-0.02344c0,0 -0.35937,0.11719 -0.73437,0.375c-0.19141,0.125 -0.40234,0.29688 -0.58594,0.56641c-0.18359,0.26953 -0.33203,0.68359 -0.27734,1.10938c0.08984,0.72266 0.55859,1.15625 0.89453,1.39453c0.33984,0.24219 0.66406,0.35547 0.66406,0.35547h0.00781l4.88281,1.64453c0.21875,0.70313 1.48828,4.875 1.79297,5.83594c0.17969,0.57422 0.35547,0.93359 0.57422,1.20703c0.10547,0.14063 0.23047,0.25781 0.37891,0.35156c0.05859,0.03516 0.12109,0.0625 0.18359,0.08594c0.01953,0.01172 0.03906,0.01563 0.0625,0.01953l-0.05078,-0.01172c0.01563,0.00391 0.02734,0.01563 0.03906,0.01953c0.03906,0.01172 0.06641,0.01563 0.11719,0.02344c0.77344,0.23438 1.39453,-0.24609 1.39453,-0.24609l0.03516,-0.02734l2.88281,-2.625l4.83203,3.70703l0.10938,0.04688c1.00781,0.44141 2.02734,0.19531 2.56641,-0.23828c0.54297,-0.4375 0.75391,-0.99609 0.75391,-0.99609l0.03516,-0.08984l3.73438,-19.12891c0.10547,-0.47266 0.13281,-0.91406 0.01563,-1.34375c-0.11719,-0.42969 -0.41797,-0.83203 -0.78125,-1.04687c-0.36719,-0.21875 -0.73047,-0.28516 -1.06641,-0.26953zM25.96875,6.04688c-0.00391,0.0625 0.00781,0.05469 -0.01953,0.17578v0.01172l-3.69922,18.92969c-0.01562,0.02734 -0.04297,0.08594 -0.11719,0.14453c-0.07812,0.0625 -0.14062,0.10156 -0.46484,-0.02734l-5.91016,-4.53125l-3.57031,3.25391l0.75,-4.78906c0,0 9.25781,-8.62891 9.65625,-9c0.39844,-0.37109 0.26563,-0.44922 0.26563,-0.44922c0.02734,-0.45312 -0.60156,-0.13281 -0.60156,-0.13281l-12.17578,7.54297l-0.00391,-0.01953l-5.83594,-1.96484v-0.00391c-0.00391,0 -0.01172,-0.00391 -0.01562,-0.00391c0.00391,0 0.03125,-0.01172 0.03125,-0.01172l0.03125,-0.01562l0.03125,-0.01172c0,0 5.21094,-2.19531 10.50781,-4.42578c2.65234,-1.11719 5.32422,-2.24219 7.37891,-3.10937c2.05469,-0.86328 3.57422,-1.49609 3.66016,-1.53125c0.08203,-0.03125 0.04297,-0.03125 0.10156,-0.03125z"></path>
                          </g>
                        </g>
                      </svg>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </Col>
          <Col lg="8">
            <div className="form-wrapper">
              <div className="form-group row">
                <div className="form-field col-md-6">
                  <input
                    type="text"
                    name="name"
                    value={userName}
                    className="form-control"
                    placeholder="Your name"
                    onChange={(event) => {
                      setUserName(event.target.value);
                    }}
                  />
                </div>
                <div className="form-field col-md-6">
                  <input
                    type="email"
                    name="email"
                    value={userEmail}
                    className="form-control"
                    placeholder="Your email"
                    onChange={(event) => {
                      if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(event.target.value)) {
                        setEmailError(true);
                      } else {
                        setEmailError(false);
                      }
                      setUserEmail(event.target.value);
                    }}
                  />
                  {emailError ? (
                    <p className="error-text">Please enter a valid email address.</p>
                  ) : (
                    ''
                  )}
                </div>
              </div>
              <div className="form-group row">
                <div className="form-field col-md-12">
                  <textarea
                    className="form-control"
                    name="message"
                    placeholder="Your message"
                    rows="5"
                    value={userMessage}
                    onChange={(event) => {
                      setUserMessage(event.target.value);
                    }}
                  ></textarea>
                </div>
              </div>
              <div className="d-flex justify-content-end">
                <Button
                  className="btn-green"
                  onClick={() => {
                    handleSubmit();
                  }}
                >
                  Submit
                </Button>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Contact;
