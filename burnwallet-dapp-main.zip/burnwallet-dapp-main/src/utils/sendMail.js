/**
 * Send email using bbackend api  .
 * Author: Nauman Sukhera
 * Date: 15 Nov, 2023
 */
import axios from 'axios';
import Swal from 'sweetalert2';

import { API_URL } from '../config';

export const SendEmail = (email, burnTokens, primaryFee, secondaryFee, nativePrice, chain, fee) => {
  axios
    .post(`${API_URL}/invoice/sendInvoiceByEmail`, {
      email,
      burnTokens,
      primaryFee,
      secondaryFee,
      nativePrice,
      chain,
      fee
    })
    .then(() => {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener('mouseenter', Swal.stopTimer);
          toast.addEventListener('mouseleave', Swal.resumeTimer);
        }
      });

      Toast.fire({
        icon: 'success',
        title: 'Email sent successfully!'
      });
    })
    .catch((error) => {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener('mouseenter', Swal.stopTimer);
          toast.addEventListener('mouseleave', Swal.resumeTimer);
        }
      });

      Toast.fire({
        icon: 'error',
        title: 'Error in sending mail!'
      });
    });
};
