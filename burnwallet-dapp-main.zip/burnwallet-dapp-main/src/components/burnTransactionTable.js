/**
 * Display Burn Transaction table .
 * Author: Nauman Sukhera
 * Date: 15 Nov, 2023
 */
import { Table, Button } from 'react-bootstrap';
import BurnTokenTransaction from './web3/burnTokenTransaction';
import { handleRefund } from '../utils/handleRefund';

export const BurnTransactionTable = ({
  isSuccess,
  selectedTokens,
  setIsProcessing,
  setBurnTokens,
  burnTokens,
  data,
  fee,
  chain,
  displayStatus,
  isProcessing,
  sendTransaction,
  handleClose,
  isLoading
}) => {
  return (
    <div className="table-responsive mb-4">
      <Table className="wallet-modal-table mb-2">
        <thead>
          <tr>
            <th>Coins</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {isSuccess &&
            selectedTokens?.map((token) => {
              return (
                <BurnTokenTransaction
                  setIsProcessing={setIsProcessing}
                  token_address={token.address}
                  balance={token.balance}
                  decimals={token.decimals}
                  symbol={token.symbol}
                  gasLimit={token.gasLimit}
                  totalFee={token.totalFee}
                  feeData={token.feeData}
                  setBurnTokens={setBurnTokens}
                  burnTokens={burnTokens}
                  feeTransactionHash={data?.hash}
                />
              );
            })}
          <tr>
            <td>
              <h4>
                (Fee) {fee} {chain.nativeCurrency.symbol}
              </h4>
            </td>
            <td>{displayStatus}</td>
            <td className="td-pay-btn">
              {isSuccess && !isProcessing ? (
                <Button
                  className="btn-blue"
                  onClick={() => {
                    handleRefund(handleClose, data,selectedTokens,burnTokens);
                  }}
                >
                  Request Refund
                </Button>
              ) : (
                <Button
                  className="btn-blue"
                  onClick={() => {
                    sendTransaction?.();
                  }}
                  disabled={isSuccess || isLoading}
                >
                  Pay
                </Button>
              )}
            </td>
          </tr>
        </tbody>
      </Table>
    </div>
  );
};
