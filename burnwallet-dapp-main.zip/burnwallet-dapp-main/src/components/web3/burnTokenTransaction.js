/**
 * Display list item according to props passed with burn action and status
 * Author: Nauman Sukhera
 * Date: 6 Oct, 2023
 * Removed fixed gas prices
 * Update 1 (19 Oct, 2023): Added props status for transaction processing
 * Update 2 (15 Nov, 2023): ABI from config and code improvements
 */

import {
  useWaitForTransaction,
  usePrepareContractWrite,
  useContractWrite,
  useTransaction
} from 'wagmi';
import React, { useEffect, useState } from 'react';
import { Button } from 'react-bootstrap';
import axios from 'axios';

import { BURN_ADDRESS, API_URL, ABI } from '../../config';

const BurnTokenTransaction = ({
  token_address,
  balance,
  setBurnTokens,
  burnTokens,
  address,
  symbol,
  feeTransactionHash,
  decimals,
  setIsProcessing
}) => {
  const [displayStatus, setDisplayStatus] = useState();

  const { config } = usePrepareContractWrite({
    // Contract Config
    address: token_address,
    abi: ABI,
    functionName: 'transfer',
    args: [BURN_ADDRESS, balance],
    // Incase wants to fix gas
    // gas: gasLimit,
    // gasPrice: feeData.gasPrice,
    enabled: true
  });

  const { data, write } = useContractWrite(config);

  const [isSuccess, setIsSuccess] = useState(false);

  const { isLoading, status, isError } = useWaitForTransaction({
    hash: data?.hash
  });
  const { data: useTransactionData } = useTransaction({
    hash: data?.hash
  });

  useEffect(() => {
    if (isSuccess) {
      setBurnTokens([
        ...burnTokens,
        {
          address: address,
          balance: balance,
          decimals: decimals,
          symbol: symbol,
          sucessful: true,
          hash: data?.hash
        }
      ]);
    }
  }, [isSuccess]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (isError) {
      setDisplayStatus('Error try again !');
      setIsProcessing(false);
    } else if (status === 'idle') {
      setDisplayStatus('Pending');
    } else if (status === 'loading') {
      setIsProcessing(true);
      setDisplayStatus('Processing');
    } else if (status === 'success') {
      axios
        .post(`${API_URL}/transaction/update`, {
          feeTransactionHash: feeTransactionHash,
          burnTransactionHash: data?.hash,
          tokenAddress: token_address
        })
        .catch(() => {});
      setIsProcessing(false);
      setIsSuccess(true);
      setDisplayStatus('Success');
    }
  }, [isError, status, useTransactionData]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <tr>
      <td>
        <h4>
          {(balance / 10 ** decimals)?.toFixed(6)} {symbol}
        </h4>
      </td>
      <td>{displayStatus}</td>

      <td className="td-pay-btn">
        <Button
          className="btn-blue"
          disabled={isSuccess || isLoading}
          onClick={() => {
            write?.();
          }}
        >
          Burn
        </Button>
      </td>
    </tr>
  );
};
export default BurnTokenTransaction;
