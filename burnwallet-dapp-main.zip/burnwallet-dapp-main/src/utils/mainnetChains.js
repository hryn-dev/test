import { EvmChain } from '@moralisweb3/common-evm-utils';

export const MAINNET_CHAIN_ID = {
  [EvmChain.BSC_TESTNET._chainlistData.chainId]: EvmChain.BSC,
  [EvmChain.SEPOLIA._chainlistData.chainId]: EvmChain.ETHEREUM,
  [EvmChain.MUMBAI._chainlistData.chainId]: EvmChain.POLYGON,
  [EvmChain.AVALANCHE_TESTNET._chainlistData.chainId]: EvmChain.AVALANCHE,
  [EvmChain.FANTOM_TESTNET._chainlistData.chainId]: EvmChain.FANTOM
};
