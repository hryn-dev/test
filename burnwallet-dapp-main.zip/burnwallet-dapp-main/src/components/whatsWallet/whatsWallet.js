import React from 'react';
import { Container, Image } from 'react-bootstrap';
import exclamationIcon from '../../assets/images/exclamation-icon.svg';
import './whatswallet.css';

const WhatsWallet = () => {
  return (
    <section className="whatswallet">
      <Container>
        <div className="whatswallet-box">
          <div className="whatswallet-box-main-content">
            <p>
              “Burning” a cryptocurrency refers to the act of sending a token to an address that can
              only receive them. Wallet addresses used for burning cryptocurrency are called
              “burner” or “dead” addresses. The act of sending tokens to these types of addresses
              effectively removes coins/tokens from the available supply, which decreases the number
              in circulation. Once a coin/token is sent to burnwallet.net it will not be put back
              into circulation.
            </p>
          </div>
          <div className="whatswallet-box-info d-flex align-items-center">
            <div className="exclamation-icon">
              <Image src={exclamationIcon} className="img-fluid" alt="exclamation icon" />
            </div>
            <p className="mb-0 text-danger">
              It’s important to note that once tokens are sent to Burnwallet.net, recovery is not
              available.
            </p>
          </div>
        </div>
      </Container>
    </section>
  );
};

export default WhatsWallet;
